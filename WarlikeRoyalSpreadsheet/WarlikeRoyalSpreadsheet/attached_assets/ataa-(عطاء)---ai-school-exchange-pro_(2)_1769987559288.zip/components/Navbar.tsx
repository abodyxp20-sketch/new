
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutGrid, PlusCircle, Settings, Home, ShieldCheck, Languages, UserCircle } from 'lucide-react';
import { UserProfile, Language, ThemeMode } from '../types';
import { translations } from '../lib/translations';

interface NavbarProps {
  user: UserProfile;
  theme: ThemeMode;
  language: Language;
  toggleLanguage: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, language, toggleLanguage }) => {
  const location = useLocation();
  const t = translations[language];

  const navItems = [
    { path: '/', icon: Home, label: language === 'ar' ? 'الرئيسية' : 'Home' },
    { path: '/marketplace', icon: LayoutGrid, label: language === 'ar' ? 'السوق' : 'Market' },
    { path: '/upload', icon: PlusCircle, label: t.donate },
    { path: '/settings', icon: Settings, label: t.settings },
  ];

  if (user.role === 'Admin' || user.role === 'Teacher') {
    navItems.push({ path: '/admin', icon: ShieldCheck, label: t.admin });
  }

  return (
    <nav className="sticky top-0 z-50 glass border-b border-slate-200/50 dark:border-slate-800/50 px-4 md:px-12">
      <div className="max-w-7xl mx-auto flex items-center justify-between h-20">
        <Link to="/" className="flex items-center gap-4 group">
          <div className="relative w-12 h-12">
            <svg viewBox="0 0 100 100" className="w-full h-full animate-spin-slow">
              <defs>
                <linearGradient id="ataagrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#10b981" />
                  <stop offset="100%" stopColor="#3b82f6" />
                </linearGradient>
              </defs>
              <rect x="15" y="15" width="70" height="70" rx="20" fill="url(#ataagrad)" />
              <path d="M30 50L45 65L70 35" stroke="white" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            </svg>
            <div className="absolute inset-0 bg-emerald-400 blur-2xl opacity-20 group-hover:opacity-40 transition-opacity" />
          </div>
          <span className="text-3xl font-black bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
            {t.appName}
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-2">
          {navItems.map((item) => (
            <Link key={item.path} to={item.path} className={`px-5 py-2.5 rounded-2xl font-bold transition-all text-sm flex items-center gap-2 ${location.pathname === item.path ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-900'}`}>
              <item.icon size={18} /> {item.label}
            </Link>
          ))}
          <div className="h-8 w-px bg-slate-200 dark:bg-slate-800 mx-2" />
          <button onClick={toggleLanguage} className="p-3 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-2xl transition-all">
            <Languages size={22} className="text-slate-500" />
          </button>
          <img src={user.profilePic} className="w-10 h-10 rounded-2xl border-2 border-emerald-500 ml-2" />
        </div>
      </div>
      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow { animation: spin-slow 12s linear infinite; }
      `}</style>
    </nav>
  );
};

export default Navbar;
