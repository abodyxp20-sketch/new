
import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Upload as UploadIcon, Loader2, CheckCircle, AlertCircle, Sparkles, MapPin, ClipboardList, Trash2 } from 'lucide-react';
import { analyzeItemImage } from '../lib/gemini';
import { UserProfile, SchoolItem, Category, Language } from '../types';
import { translations } from '../lib/translations';

interface UploadProps {
  user: UserProfile;
  language: Language;
  onUpload: (item: SchoolItem) => void;
  items?: SchoolItem[];
}

const Upload: React.FC<UploadProps> = ({ user, language, onUpload, items }) => {
  const { itemId } = useParams();
  const navigate = useNavigate();
  const editItem = itemId && items ? items.find(i => i.id === itemId) : null;

  const [image, setImage] = useState<string | null>(editItem?.imageUrl || null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const t = translations[language];
  
  const [formData, setFormData] = useState({
    name: editItem?.name || '',
    description: editItem?.description || '',
    notes: editItem?.notes || '',
    pickupLocation: editItem?.pickupLocation || '',
    category: (editItem?.category as Category) || 'Stationery',
    condition: (editItem?.condition as SchoolItem['condition']) || 'Good'
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        setImage(base64String);
        setIsAnalyzing(true);
        setError(null);
        try {
          const pureBase64 = base64String.split(',')[1];
          const result = await analyzeItemImage(pureBase64);
          
          if (result.isSafe === false) {
            setError(t.safetyError);
            setImage(null);
            return;
          }

          setFormData(prev => ({
            ...prev,
            name: result.name || prev.name,
            description: result.description || prev.description,
            category: (result.category as Category) || prev.category,
            condition: (result.condition as any) || prev.condition
          }));
        } catch (err) {
          setError(language === 'ar' ? "فشل تحليل الذكاء الاصطناعي." : "AI analysis failed.");
        } finally {
          setIsAnalyzing(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!image) return;
    setIsUploading(true);
    setTimeout(() => {
      const newItem: SchoolItem = {
        id: editItem?.id || Math.random().toString(36).substr(2, 9),
        ...formData,
        imageUrl: image,
        donorId: user.id,
        donorName: user.displayName,
        isAvailable: true,
        status: editItem ? editItem.status : 'pending',
        createdAt: editItem ? editItem.createdAt : Date.now()
      };
      onUpload(newItem);
      setIsUploading(false);
      setSuccess(true);
    }, 1500);
  };

  if (success) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center space-y-6 animate-fade-up">
        <div className="w-24 h-24 bg-emerald-100 dark:bg-emerald-900 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/20">
          <CheckCircle size={64} />
        </div>
        <h2 className="text-4xl font-black tracking-tight">{editItem ? (language === 'ar' ? 'تم التعديل!' : 'Updated!') : (language === 'ar' ? 'قيد المراجعة!' : 'Under Review!')}</h2>
        <p className="text-slate-500 text-lg font-medium">{language === 'ar' ? 'تم حفظ التغييرات بنجاح.' : 'Your changes have been saved successfully.'}</p>
        <button onClick={() => navigate('/marketplace')} className="bg-emerald-600 text-white px-10 py-4 rounded-2xl font-black shadow-xl shadow-emerald-500/30 hover:scale-105 transition-all">
          {language === 'ar' ? 'العودة للسوق' : 'Back to Market'}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto pb-12 animate-fade-up">
      <div className="mb-12">
        <h1 className="text-5xl font-black mb-3 tracking-tight">{editItem ? (language === 'ar' ? 'تعديل الأداة' : 'Edit Listing') : t.uploadTitle}</h1>
        <p className="text-slate-500 text-lg font-medium">{t.uploadDesc}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-6">
          <div 
            onClick={() => fileInputRef.current?.click()} 
            className={`aspect-square rounded-[3rem] border-4 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center overflow-hidden bg-slate-100 dark:bg-slate-900 shadow-xl group ${image ? 'border-emerald-500' : 'border-slate-300 dark:border-slate-800 hover:border-emerald-400'}`}
          >
            {image ? (
              <div className="relative w-full h-full">
                <img src={image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <p className="text-white font-black text-xl">{language === 'ar' ? 'تغيير الصورة' : 'Change Image'}</p>
                </div>
              </div>
            ) : (
              <div className="text-center p-10">
                <div className="w-24 h-24 bg-emerald-500/10 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <UploadIcon size={48} />
                </div>
                <p className="font-black text-xl mb-1">{language === 'ar' ? 'ارفع صورة الأداة' : 'Upload Photo'}</p>
                <p className="text-slate-400 font-medium">PNG, JPG up to 10MB</p>
              </div>
            )}
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageChange} />
          </div>

          {isAnalyzing && (
            <div className="glass p-6 rounded-[2rem] flex items-center gap-5 border-emerald-500/20 animate-pulse shadow-lg">
              <Loader2 className="animate-spin text-emerald-600" size={28} />
              <div className="flex-1">
                <p className="text-sm font-black flex items-center gap-2"><Sparkles size={18} className="text-amber-500" /> {language === 'ar' ? 'الذكاء الاصطناعي يتحقق من الأمان...' : 'Verifying safety with AI...'}</p>
                <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-emerald-500 animate-[loading_2s_infinite]" />
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="bg-rose-50 dark:bg-rose-900/20 text-rose-600 p-6 rounded-[2rem] flex items-center gap-4 border border-rose-200 dark:border-rose-800/50 shadow-lg animate-in shake">
              <AlertCircle size={32} />
              <p className="font-black text-lg">{error}</p>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="glass p-10 rounded-[3rem] space-y-8 border border-slate-200 dark:border-slate-800 shadow-2xl">
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-3">{language === 'ar' ? 'اسم الأداة' : 'Item Name'}</label>
              <input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full p-5 rounded-2xl bg-white dark:bg-slate-900 border dark:border-slate-800 outline-none focus:ring-4 focus:ring-emerald-500/20 font-black text-lg transition-all" />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-3">{t.pickup}</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input required placeholder="e.g. Lab 4" value={formData.pickupLocation} onChange={e => setFormData({...formData, pickupLocation: e.target.value})} className="w-full pl-12 p-5 rounded-2xl bg-white dark:bg-slate-900 border dark:border-slate-800 outline-none font-bold" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-3">{t.condition}</label>
                <select value={formData.condition} onChange={e => setFormData({...formData, condition: e.target.value as any})} className="w-full p-5 rounded-2xl bg-white dark:bg-slate-900 border dark:border-slate-800 outline-none font-bold">
                  <option>New</option><option>Like New</option><option>Good</option><option>Fair</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-3">{t.notes}</label>
              <div className="relative">
                <ClipboardList className="absolute left-4 top-5 text-slate-400" size={20} />
                <textarea rows={3} placeholder="Notes for the next student..." value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} className="w-full pl-12 p-5 rounded-2xl bg-white dark:bg-slate-900 border dark:border-slate-800 outline-none font-medium leading-relaxed" />
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button 
              type="submit" 
              disabled={!image || isUploading} 
              className={`flex-1 py-5 rounded-2xl font-black text-xl shadow-2xl transition-all active:scale-95 ${!image || isUploading ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed' : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-500/30'}`}
            >
              {isUploading ? <Loader2 className="animate-spin mx-auto" /> : (editItem ? (language === 'ar' ? 'حفظ التعديلات' : 'Save Changes') : t.donate)}
            </button>
            {editItem && (
               <button type="button" onClick={() => navigate('/marketplace')} className="px-8 py-5 rounded-2xl bg-slate-100 dark:bg-slate-800 font-black text-xl active:scale-95 transition-all">
                 {language === 'ar' ? 'إلغاء' : 'Cancel'}
               </button>
            )}
          </div>
        </form>
      </div>
      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}</style>
    </div>
  );
};

export default Upload;
