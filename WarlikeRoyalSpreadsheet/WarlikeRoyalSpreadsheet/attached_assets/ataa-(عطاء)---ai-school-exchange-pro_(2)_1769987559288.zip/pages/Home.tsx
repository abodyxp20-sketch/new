
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Gift, Recycle, Users, Sparkles, Target, Zap, Trophy, HelpCircle, ShieldCheck, Award, Leaf, Coins, Cloud } from 'lucide-react';
import { UserProfile, Language, SchoolItem } from '../types';
import { translations } from '../lib/translations';
import { ALL_BADGES } from '../App';

interface HomeProps {
  user: UserProfile;
  language: Language;
  items: SchoolItem[];
}

const Home: React.FC<HomeProps> = ({ user, language, items }) => {
  const t = translations[language];
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('active');
      });
    }, { threshold: 0.1 });

    const reveals = document.querySelectorAll('.reveal');
    reveals.forEach(el => observer.observe(el));
    return () => reveals.forEach(el => observer.unobserve(el));
  }, []);

  const topContributors = [
    { name: "Ali Ahmed", points: 1250, avatar: "https://i.pravatar.cc/150?u=ali" },
    { name: "Sarah Ahmed", points: user.socialPoints, avatar: user.profilePic },
    { name: "Omar Khalid", points: 840, avatar: "https://i.pravatar.cc/150?u=omar" }
  ].sort((a, b) => b.points - a.points);

  // Sustainability Logic
  const approvedCount = items.filter(i => i.status === 'approved').length + 150;
  const treesSaved = Math.floor(approvedCount * 0.4);
  const co2Reduced = (approvedCount * 0.5).toFixed(1);
  const moneySaved = approvedCount * 20;

  return (
    <div className="space-y-16 md:space-y-24 pb-12 overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-[2rem] md:rounded-[3rem] bg-gradient-to-br from-emerald-600 via-emerald-500 to-blue-600 text-white p-8 md:p-24 shadow-2xl animate-fade-up">
        <div className="relative z-10 max-w-2xl text-center md:text-left">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-1.5 rounded-full text-xs md:text-sm font-bold mb-6 md:mb-8 mx-auto md:mx-0">
            <Sparkles size={14} className="text-amber-300" /> {t.slogan}
          </div>
          <h1 className="text-4xl md:text-7xl font-black leading-[1.1] mb-6 md:mb-8 tracking-tight">
            {t.heroTitle}
          </h1>
          <p className="text-lg md:text-2xl text-white/80 mb-8 md:mb-12 max-w-xl leading-relaxed font-medium mx-auto md:mx-0">
            {t.heroDesc}
          </p>
          <div className="flex flex-col sm:flex-row justify-center md:justify-start gap-4 md:gap-6">
            <Link to="/marketplace" className="bg-white text-emerald-600 px-8 py-4 md:py-5 rounded-2xl font-black text-lg hover-liquid active-liquid flex items-center justify-center gap-3 shadow-xl">
              {t.browse} <ArrowRight size={20} className={language === 'ar' ? 'rotate-180' : ''} />
            </Link>
            <Link to="/upload" className="bg-emerald-700/40 backdrop-blur-xl border border-white/20 text-white px-8 py-4 md:py-5 rounded-2xl font-black text-lg hover:bg-emerald-700/60 transition-all text-center">
              {t.donate}
            </Link>
          </div>
        </div>
        <div className="absolute -top-20 -right-20 w-64 md:w-[500px] h-64 md:h-[500px] bg-white/10 rounded-full blur-[120px]" />
      </section>

      {/* Eco-Impact Dashboard */}
      <section className="reveal space-y-10">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-black uppercase tracking-widest text-xs mb-4">
            <Leaf size={18} /> {t.ecoDashboard}
          </div>
          <h2 className="text-3xl md:text-4xl font-black">{t.ecoDesc}</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { label: t.treesSaved, value: treesSaved, icon: Leaf, color: "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30", unit: "Trees" },
            { label: t.co2Saved, value: co2Reduced, icon: Cloud, color: "bg-blue-100 text-blue-600 dark:bg-blue-900/30", unit: "kg" },
            { label: t.moneySaved, value: `$${moneySaved}`, icon: Coins, color: "bg-amber-100 text-amber-600 dark:bg-amber-900/30", unit: "USD" },
          ].map((stat, i) => (
            <div key={i} className="glass p-10 rounded-[2.5rem] border-slate-200/50 dark:border-slate-800/50 hover-liquid flex flex-col items-center text-center group">
              <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform ${stat.color}`}>
                <stat.icon size={40} />
              </div>
              <p className="text-4xl md:text-5xl font-black mb-1 tracking-tighter">{stat.value}</p>
              <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">{stat.label}</p>
              <div className="mt-4 h-1 w-12 bg-slate-200 dark:bg-slate-800 rounded-full group-hover:w-24 transition-all duration-500" />
            </div>
          ))}
        </div>
      </section>

      {/* Impact Stats Grid (Legacy) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 md:gap-8 reveal">
        {[
          { label: t.totalDonations, value: items.length + 1400, icon: Gift, color: "text-rose-500" },
          { label: t.studentsHelped, value: "892", icon: Users, color: "text-blue-500" },
          { label: t.co2Saved, value: co2Reduced + " kg", icon: Recycle, color: "text-emerald-500" },
        ].map((stat, i) => (
          <div key={i} className="glass p-8 md:p-10 rounded-[2rem] md:rounded-[2.5rem] text-center border-slate-200/50 dark:border-slate-800/50 hover-liquid">
            <div className={`mx-auto w-16 h-16 md:w-20 md:h-20 mb-6 flex items-center justify-center rounded-2xl md:rounded-3xl bg-slate-100 dark:bg-slate-900 ${stat.color}`}>
              <stat.icon size={32} />
            </div>
            <p className="text-4xl md:text-5xl font-black mb-2 tracking-tighter">{stat.value}</p>
            <p className="text-slate-500 font-bold uppercase tracking-widest text-xs md:text-sm">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Achievements Horizontal Scroll */}
      <div className="reveal space-y-6">
        <h3 className="text-2xl md:text-3xl font-black flex items-center gap-3">
          <Award className="text-amber-500" /> {t.unlockedBadges}
        </h3>
        <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-hide -mx-4 px-4">
          {ALL_BADGES.map((badge) => {
            const unlocked = user.unlockedBadges.includes(badge.id);
            return (
              <div key={badge.id} className={`flex-shrink-0 w-48 p-6 rounded-[2rem] border transition-all duration-500 ${unlocked ? 'glass border-emerald-500/30' : 'bg-slate-100 dark:bg-slate-900 opacity-40 grayscale border-transparent'}`}>
                <div className={`text-4xl mb-4 p-4 rounded-2xl inline-block ${unlocked ? badge.color + ' text-white shadow-lg' : 'bg-slate-200 dark:bg-slate-800'}`}>
                  {badge.icon}
                </div>
                <h4 className="font-black text-lg mb-1">{language === 'ar' ? badge.nameAr : badge.nameEn}</h4>
                <p className="text-xs text-slate-500 font-bold">{badge.condition}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Leaderboard Section */}
      <section className="reveal space-y-10">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 font-black uppercase tracking-widest text-xs mb-4">
            <Trophy size={18} /> {t.leaderboard}
          </div>
          <h2 className="text-3xl md:text-4xl font-black">{language === 'ar' ? 'أبطال مجتمع عطاء' : 'Ataa Community Heroes'}</h2>
        </div>

        <div className="max-w-4xl mx-auto space-y-4">
          {topContributors.map((c, i) => (
            <div key={i} className={`glass p-4 md:p-6 rounded-2xl flex items-center justify-between hover-liquid border-slate-200/30 dark:border-slate-800/30 ${c.name === user.displayName ? 'ring-2 ring-emerald-500' : ''}`}>
              <div className="flex items-center gap-4 md:gap-6">
                <span className="text-xl md:text-2xl font-black text-slate-300 w-6 md:w-8">{i + 1}</span>
                <img src={c.avatar} className="w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl object-cover border-2 border-emerald-500/20" />
                <div>
                  <p className="font-black text-base md:text-lg">{c.name}</p>
                  <p className="text-xs text-slate-500 font-bold">{language === 'ar' ? 'طالب معطاء' : 'Top Donor'}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xl md:text-2xl font-black text-emerald-600">{c.points}</p>
                <p className="text-[10px] font-black text-slate-400 uppercase">Points</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
