
import React, { useState, useRef } from 'react';
import { 
  User, Bell, Shield, Moon, Sun, LogOut, ChevronRight, 
  Languages, Monitor, Mail, UserCircle, Lock, HelpCircle, 
  MessageSquare, Camera, Trash2, Loader2, Sparkles, AlertCircle, 
  Award, ChevronDown, CheckCircle2, ShieldCheck, Eye, EyeOff,
  Target
} from 'lucide-react';
import { UserProfile, Language, ThemeMode } from '../types';
import { translations } from '../lib/translations';
import { analyzeItemImage } from '../lib/gemini';
import { ALL_BADGES } from '../App';

interface SettingsProps {
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
  language: Language;
  toggleLanguage: () => void;
}

const Settings: React.FC<SettingsProps> = ({ user, setUser, theme, setTheme, language, toggleLanguage }) => {
  const [activeTab, setActiveTab] = useState<'account' | 'appearance' | 'notify' | 'privacy' | 'support'>('account');
  const [isUpdatingPic, setIsUpdatingPic] = useState(false);
  const [picError, setPicError] = useState<string | null>(null);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = translations[language];

  const handlePicChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        setIsUpdatingPic(true);
        setPicError(null);
        try {
          const pureBase64 = base64.split(',')[1];
          const result = await analyzeItemImage(pureBase64);
          if (result.isSafe === false) {
            setPicError(language === 'ar' ? "الصورة غير لائقة للمدرسة." : "Image is not school-appropriate.");
            return;
          }
          setUser(prev => ({ ...prev, profilePic: base64 }));
        } catch (err) {
          setPicError("Update failed.");
        } finally {
          setIsUpdatingPic(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePic = () => {
    setUser(prev => ({ ...prev, profilePic: `https://ui-avatars.com/api/?name=${prev.displayName}&background=random` }));
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setSendSuccess(true);
      setTimeout(() => setSendSuccess(false), 3000);
    }, 1500);
  };

  const NavItem = ({ id, icon: Icon, label }: any) => (
    <button 
      onClick={() => setActiveTab(id)} 
      className={`w-full flex items-center justify-between p-4 md:p-5 rounded-2xl md:rounded-[1.5rem] transition-all duration-300 active-liquid ${activeTab === id ? 'bg-emerald-600 text-white shadow-xl translate-x-1' : 'hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-600 dark:text-slate-400'}`}
    >
      <div className="flex items-center gap-4"><Icon size={22} /><span className="font-black text-base md:text-lg">{label}</span></div>
      <ChevronRight size={18} className={`${language === 'ar' ? 'rotate-180' : ''} ${activeTab === id ? 'opacity-100' : 'opacity-30'}`} />
    </button>
  );

  const SectionTitle = ({ children, icon: Icon }: any) => (
    <div className="flex items-center gap-4 mb-8 md:mb-10 border-b dark:border-slate-800 pb-5">
      <div className="p-3 bg-emerald-100 dark:bg-emerald-900 text-emerald-600 rounded-2xl shadow-inner">
        <Icon size={24} />
      </div>
      <h3 className="text-2xl md:text-3xl font-black tracking-tight">{children}</h3>
    </div>
  );

  const Toggle = ({ active, onToggle, label, desc, icon: Icon }: any) => (
    <div className="flex items-center justify-between p-6 glass rounded-2xl hover:bg-white dark:hover:bg-slate-900 transition-all group shadow-sm">
      <div className="flex items-center gap-5">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${active ? 'bg-emerald-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
          <Icon size={24} />
        </div>
        <div>
          <p className="font-black text-lg">{label}</p>
          <p className="text-sm text-slate-500 font-medium">{desc}</p>
        </div>
      </div>
      <button 
        onClick={onToggle}
        className={`w-14 h-8 rounded-full relative transition-all duration-300 ${active ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'}`}
      >
        <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-md ${active ? (language === 'ar' ? 'left-1' : 'right-1') : (language === 'ar' ? 'right-1' : 'left-1')}`} />
      </button>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 min-h-[80vh] pb-20 animate-fade-up">
      {/* Sidebar */}
      <div className="lg:col-span-4 space-y-4">
        <div className="mb-8 md:mb-12">
          <h1 className="text-4xl md:text-5xl font-black mb-3 tracking-tighter">{t.settings}</h1>
          <p className="text-slate-500 font-bold text-base md:text-lg">{(t as any).slogan}</p>
        </div>
        <div className="space-y-2 md:space-y-3">
          <NavItem id="account" icon={UserCircle} label={t.account} />
          <NavItem id="appearance" icon={Monitor} label={t.appearance} />
          <NavItem id="notify" icon={Bell} label={language === 'ar' ? 'التنبيهات' : 'Notifications'} />
          <NavItem id="privacy" icon={Shield} label={t.privacy} />
          <NavItem id="support" icon={HelpCircle} label={t.support} />
        </div>
        <hr className="my-8 md:my-10 border-slate-200 dark:border-slate-800" />
        <button className="w-full flex items-center gap-4 p-5 rounded-2xl text-rose-500 font-black text-lg hover:bg-rose-50 dark:hover:bg-rose-900/10 transition-all active-liquid">
          <LogOut size={24} /> {t.signOut}
        </button>
      </div>

      {/* Main Content Area */}
      <div className="lg:col-span-8 glass p-6 md:p-12 rounded-[2.5rem] md:rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-xl relative overflow-x-hidden">
        
        {/* Account Tab */}
        {activeTab === 'account' && (
          <div className="space-y-10 md:space-y-12">
            <SectionTitle icon={UserCircle}>{t.account}</SectionTitle>
            <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12 group">
              <div className="relative">
                <div className="w-32 h-32 md:w-48 md:h-48 rounded-[2rem] md:rounded-[3rem] overflow-hidden border-4 border-emerald-500 shadow-2xl relative">
                  <img src={user.profilePic} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  {isUpdatingPic && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
                      <Loader2 className="animate-spin text-white" size={32} />
                    </div>
                  )}
                </div>
                <div className="absolute -bottom-2 -right-2 flex gap-2">
                  <button onClick={() => fileInputRef.current?.click()} className="bg-emerald-600 text-white p-3 rounded-xl shadow-xl hover:scale-110 active-liquid transition-all border-2 border-white dark:border-slate-900">
                    <Camera size={20} />
                  </button>
                  <button onClick={handleRemovePic} className="bg-slate-100 dark:bg-slate-800 text-slate-500 p-3 rounded-xl shadow-xl hover:scale-110 active-liquid transition-all border-2 border-white dark:border-slate-900">
                    <Trash2 size={20} />
                  </button>
                </div>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePicChange} />
              </div>
              <div className="flex-1 space-y-4 text-center md:text-left">
                <h3 className="text-3xl md:text-4xl font-black tracking-tighter">{user.displayName}</h3>
                <p className="text-slate-500 text-lg md:text-xl font-medium">{user.email}</p>
                {picError && <p className="text-rose-500 font-black flex items-center gap-2 justify-center md:justify-start text-sm"><AlertCircle size={14}/> {picError}</p>}
                <div className="flex flex-wrap justify-center md:justify-start gap-2 pt-2">
                   <span className="px-5 py-1.5 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 text-xs font-black rounded-xl border border-emerald-500/20">Level {Math.floor(user.socialPoints/100)}</span>
                   <span className="px-5 py-1.5 bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-xs font-black rounded-xl border border-blue-500/20">{user.grade}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-8 md:gap-10 pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
                <div>
                  <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-3">{language === 'ar' ? 'الاسم' : 'Display Name'}</label>
                  <input value={user.displayName} onChange={e => setUser({...user, displayName: e.target.value})} className="w-full p-4 md:p-5 rounded-2xl bg-slate-50/50 dark:bg-slate-900/50 border dark:border-slate-800 outline-none focus:ring-4 focus:ring-emerald-500/20 font-black text-lg transition-all" />
                </div>
                <div>
                  <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-3">{t.grade}</label>
                  <input value={user.grade} onChange={e => setUser({...user, grade: e.target.value})} className="w-full p-4 md:p-5 rounded-2xl bg-slate-50/50 dark:bg-slate-900/50 border dark:border-slate-800 outline-none focus:ring-4 focus:ring-emerald-500/20 font-black text-lg transition-all" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-3">{t.bio}</label>
                <textarea rows={3} value={user.bio} onChange={e => setUser({...user, bio: e.target.value})} placeholder="About you..." className="w-full p-4 md:p-5 rounded-2xl bg-slate-50/50 dark:bg-slate-900/50 border dark:border-slate-800 outline-none focus:ring-4 focus:ring-emerald-500/20 font-medium text-lg transition-all" />
              </div>
            </div>
            <button className="bg-emerald-600 text-white px-10 py-4 md:py-5 rounded-2xl font-black text-lg md:text-xl shadow-2xl hover-liquid active-liquid w-full md:w-auto">
              {t.save}
            </button>
          </div>
        )}

        {/* Appearance Tab */}
        {activeTab === 'appearance' && (
          <div className="space-y-10 animate-fade-up">
            <SectionTitle icon={Monitor}>{t.appearance}</SectionTitle>
            <div className="flex flex-col gap-6">
              <div className="flex items-center justify-between p-6 md:p-8 glass rounded-[2rem] border-slate-100 dark:border-slate-800 shadow-lg group">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 md:w-16 md:h-16 bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center rounded-xl md:rounded-[1.5rem] text-blue-600 group-hover:scale-110 transition-transform">
                     <Languages size={28} />
                   </div>
                   <div>
                     <p className="font-black text-xl md:text-2xl tracking-tighter">{t.language}</p>
                     <p className="text-base md:text-lg text-slate-500 font-bold">{language === 'ar' ? 'العربية' : 'English'}</p>
                   </div>
                </div>
                <button onClick={toggleLanguage} className="bg-emerald-600 text-white px-6 md:px-10 py-3 md:py-4 rounded-xl md:rounded-2xl font-black text-lg uppercase active-liquid shadow-lg">
                  {language}
                </button>
              </div>

              <div className="p-8 md:p-10 glass rounded-[2.5rem] md:rounded-[3rem] border-slate-100 dark:border-slate-800 space-y-8 shadow-xl">
                <p className="font-black text-xl md:text-2xl flex items-center gap-4 tracking-tight">{t.theme}</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
                  {(['light', 'dark', 'system'] as ThemeMode[]).map(m => (
                    <button 
                      key={m} 
                      onClick={() => setTheme(m)} 
                      className={`flex items-center justify-center gap-3 py-4 md:py-6 rounded-2xl md:rounded-[2rem] font-black text-lg border transition-all duration-500 ${theme === m ? 'bg-emerald-600 border-emerald-600 text-white shadow-2xl shadow-emerald-500/40 scale-105' : 'border-slate-200 dark:border-slate-800 hover:bg-white dark:hover:bg-slate-900'}`}
                    >
                      {m === 'light' && <Sun size={20} />}
                      {m === 'dark' && <Moon size={20} />}
                      {m === 'system' && <Monitor size={20} />}
                      {t[m as keyof typeof translations.en]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notify' && (
          <div className="space-y-8 animate-fade-up">
            <SectionTitle icon={Bell}>{(t as any).appName} Notifications</SectionTitle>
            <div className="space-y-4">
              <Toggle 
                active={user.preferences.notifications.inApp}
                onToggle={() => setUser(prev => ({...prev, preferences: {...prev.preferences, notifications: {...prev.preferences.notifications, inApp: !prev.preferences.notifications.inApp}}}))}
                label={(t as any).notifyItemUpdates}
                desc={(t as any).notifyItemDesc}
                icon={CheckCircle2}
              />
              <Toggle 
                active={true}
                onToggle={() => {}}
                label={(t as any).notifyGradeAlerts}
                desc={(t as any).notifyGradeDesc}
                icon={Target}
              />
              <Toggle 
                active={user.preferences.notifications.email}
                onToggle={() => setUser(prev => ({...prev, preferences: {...prev.preferences, notifications: {...prev.preferences.notifications, email: !prev.preferences.notifications.email}}}))}
                label={(t as any).notifyBadges}
                desc={(t as any).notifyBadgesDesc}
                icon={Award}
              />
            </div>
          </div>
        )}

        {/* Privacy Tab */}
        {activeTab === 'privacy' && (
          <div className="space-y-8 animate-fade-up">
            <SectionTitle icon={Shield}>{t.privacy}</SectionTitle>
            
            <div className="space-y-4">
              <Toggle 
                active={user.preferences.privacyShowHistory}
                onToggle={() => setUser(prev => ({...prev, preferences: {...prev.preferences, privacyShowHistory: !prev.preferences.privacyShowHistory}}))}
                label={(t as any).profileVisibility}
                desc={(t as any).profileVisibilityDesc}
                icon={user.preferences.privacyShowHistory ? Eye : EyeOff}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-6 glass rounded-2xl border-emerald-500/10">
                  <div className="flex items-center gap-3 mb-3 text-emerald-600">
                    <ShieldCheck size={20} />
                    <h4 className="font-black">{(t as any).aiSafetyInfo}</h4>
                  </div>
                  <p className="text-sm text-slate-500 font-medium">{(t as any).aiSafetyDesc}</p>
                </div>
                <div className="p-6 glass rounded-2xl border-blue-500/10">
                  <div className="flex items-center gap-3 mb-3 text-blue-600">
                    <Lock size={20} />
                    <h4 className="font-black">{(t as any).dataProtection}</h4>
                  </div>
                  <p className="text-sm text-slate-500 font-medium">{(t as any).dataProtectionDesc}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Support & FAQ Tab */}
        {activeTab === 'support' && (
          <div className="space-y-12 animate-fade-up">
            <SectionTitle icon={HelpCircle}>{t.support}</SectionTitle>
            
            <div className="space-y-4">
              <h4 className="text-xl font-black px-2">{(t as any).faqTitle}</h4>
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="glass rounded-2xl overflow-hidden border-slate-100 dark:border-slate-800">
                    <button 
                      onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                      className="w-full flex items-center justify-between p-5 hover:bg-white dark:hover:bg-slate-900 transition-all text-left"
                    >
                      <span className="font-black text-slate-700 dark:text-slate-200">{(t as any)[`faqQ${i}`]}</span>
                      <ChevronDown size={20} className={`text-slate-400 transition-transform ${expandedFaq === i ? 'rotate-180' : ''}`} />
                    </button>
                    {expandedFaq === i && (
                      <div className="p-5 pt-0 text-slate-500 font-medium text-sm leading-relaxed animate-in slide-in-from-top-2">
                        {(t as any)[`faqA${i}`]}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="glass p-8 rounded-[2.5rem] border-slate-200 dark:border-slate-800 shadow-lg">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 rounded-xl flex items-center justify-center">
                  <MessageSquare size={24} />
                </div>
                <div>
                  <h4 className="text-xl font-black">{(t as any).contactTitle}</h4>
                  <p className="text-sm text-slate-500 font-medium">{(t as any).contactDesc}</p>
                </div>
              </div>

              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input required placeholder={(t as any).subject} className="w-full p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border dark:border-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold" />
                  <input required type="email" placeholder="Email" value={user.email} disabled className="w-full p-4 rounded-xl bg-slate-100 dark:bg-slate-800 border dark:border-slate-800 opacity-60 font-bold" />
                </div>
                <textarea required rows={4} placeholder={(t as any).message} className="w-full p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border dark:border-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-medium" />
                
                <button 
                  disabled={isSending || sendSuccess}
                  className={`w-full py-4 rounded-xl font-black text-lg transition-all flex items-center justify-center gap-3 ${sendSuccess ? 'bg-emerald-100 text-emerald-600 border border-emerald-500/20' : 'bg-emerald-600 text-white shadow-xl shadow-emerald-500/20 hover:scale-[1.02] active-liquid'}`}
                >
                  {isSending ? <Loader2 className="animate-spin" /> : sendSuccess ? <><CheckCircle2 size={20} /> Sent Successfully!</> : (t as any).sendMessage}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;
