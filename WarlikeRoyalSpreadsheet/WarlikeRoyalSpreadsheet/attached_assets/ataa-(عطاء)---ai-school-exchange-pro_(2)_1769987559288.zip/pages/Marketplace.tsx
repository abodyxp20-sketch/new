
import React, { useState, useEffect } from 'react';
import { Search, Filter, MapPin, Package, ShoppingBag, Edit3, Star, Heart, Plus, X, QrCode, Sparkles, Zap, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { SchoolItem, Category, Language, UserProfile, ItemRequest, ThemeMode } from '../types';
import { translations } from '../lib/translations';
import { performSemanticSearch } from '../lib/gemini';

interface MarketplaceProps {
  items: SchoolItem[];
  requests: ItemRequest[];
  user: UserProfile;
  language: Language;
  theme: ThemeMode;
  onPostRequest: (req: ItemRequest) => void;
}

const Marketplace: React.FC<MarketplaceProps> = ({ items, requests, user, language, theme, onPostRequest }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAISearching, setIsAISearching] = useState(false);
  const [viewMode, setViewMode] = useState<'items' | 'requests'>('items');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All' | 'My Listings'>('All');
  const [selectedItem, setSelectedItem] = useState<SchoolItem | null>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requestInput, setRequestInput] = useState({ name: '', category: 'Stationery' as Category });
  
  const t = translations[language];
  const navigate = useNavigate();

  // AI Recommendations logic (simulated personalization based on grade)
  const recommendedItems = items.filter(i => 
    i.status === 'approved' && 
    (i.category === 'Books' || i.category === 'Electronics') &&
    i.donorId !== user.id
  ).slice(0, 3);

  const handleSemanticSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;
    
    setIsAISearching(true);
    try {
      const result = await performSemanticSearch(searchTerm, language);
      if (result.category) {
        setSelectedCategory(result.category as any);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsAISearching(false);
    }
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchTerm.toLowerCase());
    let matchesCategory = false;
    if (selectedCategory === 'All') matchesCategory = true;
    else if (selectedCategory === 'My Listings') matchesCategory = item.donorId === user.id;
    else matchesCategory = item.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const handlePostRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const newReq: ItemRequest = {
      id: Math.random().toString(36).substr(2, 9),
      studentId: user.id,
      studentName: user.displayName,
      itemName: requestInput.name,
      category: requestInput.category,
      createdAt: Date.now()
    };
    onPostRequest(newReq);
    setShowRequestModal(false);
    setRequestInput({ name: '', category: 'Stationery' });
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 animate-fade-up">
        <div>
          <h1 className="text-4xl font-black mb-2 tracking-tight flex items-center gap-3">
            {t.marketTitle} <Sparkles className="text-amber-500 animate-pulse" size={24} />
          </h1>
          <p className="text-slate-500 font-medium">{t.marketDesc}</p>
        </div>

        <div className="flex items-center gap-3">
          <form onSubmit={handleSemanticSearch} className="relative group flex-1 md:flex-none">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={20} />
            <input 
              type="text" 
              placeholder={language === 'ar' ? 'اسأل الذكاء الاصطناعي... "أنا بردان" أو "محتاج آلة حاسبة"' : 'Ask AI... "I\'m cold" or "I need a calculator"'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 pr-12 py-3.5 rounded-2xl glass border-emerald-500/20 outline-none focus:ring-4 focus:ring-emerald-500/20 w-full md:w-[400px] font-medium transition-all"
            />
            <button 
              type="submit" 
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 rounded-xl transition-all"
              disabled={isAISearching}
            >
              {isAISearching ? <Loader2 className="animate-spin" size={18} /> : <Zap size={18} />}
            </button>
          </form>
          <button 
            onClick={() => setShowRequestModal(true)}
            className="p-3.5 rounded-2xl bg-emerald-600 text-white hover:bg-emerald-700 transition-all hover:scale-110 active-liquid shadow-xl shadow-emerald-500/20"
          >
            <Plus size={24} />
          </button>
        </div>
      </div>

      {/* AI Recommendations */}
      {viewMode === 'items' && recommendedItems.length > 0 && (
        <div className="bg-gradient-to-r from-emerald-500/10 to-blue-500/10 p-6 rounded-[2.5rem] border border-emerald-500/20 animate-fade-up">
          <h3 className="text-lg font-black mb-4 flex items-center gap-2">
            <Sparkles size={18} className="text-amber-500" />
            {language === 'ar' ? 'مقترح لك بناءً على صفك الدراسي' : 'Recommended for You (AI)'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {recommendedItems.map(item => (
              <div key={item.id} onClick={() => setSelectedItem(item)} className="glass p-3 rounded-2xl flex items-center gap-4 cursor-pointer hover:bg-white dark:hover:bg-slate-900 transition-all">
                <img src={item.imageUrl} className="w-16 h-16 rounded-xl object-cover" />
                <div className="overflow-hidden">
                   <p className="font-black text-sm truncate">{item.name}</p>
                   <p className="text-[10px] text-slate-500 font-bold uppercase">{item.category}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* View Toggle */}
      <div className="flex gap-2 p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl w-fit animate-fade-up">
        <button 
          onClick={() => setViewMode('items')}
          className={`px-8 py-3 rounded-xl font-black text-sm transition-all ${viewMode === 'items' ? 'bg-white dark:bg-slate-800 shadow-md text-emerald-600' : 'text-slate-500'}`}
        >
          {t.browse}
        </button>
        <button 
          onClick={() => setViewMode('requests')}
          className={`px-8 py-3 rounded-xl font-black text-sm transition-all ${viewMode === 'requests' ? 'bg-white dark:bg-slate-800 shadow-md text-emerald-600' : 'text-slate-500'}`}
        >
          {t.requests}
        </button>
      </div>

      {viewMode === 'items' ? (
        <>
          {/* Category Chips */}
          <div className="flex gap-3 overflow-x-auto pb-4 -mx-4 px-4 scrollbar-hide animate-fade-up">
            {['All', 'My Listings', 'Stationery', 'Electronics', 'Books', 'Uniforms', 'Art Supplies', 'Other'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat as any)}
                className={`flex-shrink-0 px-8 py-3.5 rounded-2xl text-sm font-black transition-all shadow-md active-liquid ${
                  selectedCategory === cat 
                    ? 'bg-emerald-600 text-white shadow-xl shadow-emerald-500/30 ring-2 ring-emerald-400' 
                    : 'glass text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-900'
                }`}
              >
                {cat === 'My Listings' ? (language === 'ar' ? 'أدواتي' : 'My Listings') : cat}
              </button>
            ))}
          </div>

          {/* Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 animate-fade-up">
            {filteredItems.map((item) => (
              <div key={item.id} className="group glass rounded-[2.5rem] overflow-hidden hover:shadow-2xl transition-all duration-500 border border-slate-100 dark:border-slate-800 flex flex-col relative">
                <div className="aspect-[4/3] relative overflow-hidden" onClick={() => setSelectedItem(item)}>
                  <img 
                    src={item.imageUrl} 
                    alt={item.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 cursor-pointer" 
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400 shadow-lg flex items-center gap-1">
                      <Zap size={10} /> {item.category}
                    </div>
                  </div>
                </div>
                
                <div className="p-7 flex-1 flex flex-col">
                  <h3 className="font-black text-xl leading-tight mb-2 group-hover:text-emerald-600 transition-colors cursor-pointer" onClick={() => setSelectedItem(item)}>{item.name}</h3>
                  <p className="text-slate-500 font-medium text-sm mb-6 line-clamp-2 leading-relaxed">{item.description}</p>
                  
                  <div className="mt-auto pt-5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img src={`https://ui-avatars.com/api/?name=${item.donorName}&background=random`} className="w-8 h-8 rounded-xl ring-2 ring-emerald-500/10" />
                      <span className="text-xs text-slate-500 font-bold">{item.donorName}</span>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setSelectedItem(item)}
                        className="bg-emerald-100 text-emerald-600 p-2.5 rounded-xl hover:bg-emerald-600 hover:text-white transition-all active-liquid shadow-lg"
                      >
                        <ShoppingBag size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        /* Requests Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-up">
          {requests.length > 0 ? requests.map(req => (
            <div key={req.id} className="glass p-8 rounded-[2rem] border-blue-500/10 hover-liquid relative overflow-hidden">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-xl flex items-center justify-center">
                  <Heart size={24} />
                </div>
                <div>
                  <h4 className="font-black text-lg">{req.itemName}</h4>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{req.category}</p>
                </div>
              </div>
              <p className="text-sm text-slate-500 font-medium mb-4">
                {language === 'ar' ? 'طلب بواسطة ' : 'Requested by '} <span className="text-slate-800 dark:text-slate-200 font-black">{req.studentName}</span>
              </p>
              <div className="text-[10px] text-slate-400 font-bold uppercase">
                Posted {new Date(req.createdAt).toLocaleDateString()}
              </div>
            </div>
          )) : (
            <div className="col-span-full py-20 text-center opacity-50">
               <Heart size={48} className="mx-auto mb-4" />
               <p className="font-black text-xl">{t.noRequests}</p>
            </div>
          )}
        </div>
      )}

      {/* Item Detail Modal with QR Code */}
      {selectedItem && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto relative animate-in zoom-in-95 duration-300">
            <button 
              onClick={() => setSelectedItem(null)}
              className="absolute top-6 right-6 p-3 bg-slate-100 dark:bg-slate-800 rounded-2xl hover:bg-rose-500 hover:text-white transition-all z-10"
            >
              <X size={24} />
            </button>
            
            <div className="grid grid-cols-1 md:grid-cols-2 h-full">
              <div className="h-full">
                <img src={selectedItem.imageUrl} className="w-full h-full object-cover md:rounded-l-[3rem]" />
              </div>
              <div className="p-8 md:p-12 space-y-8">
                <div>
                  <div className="flex items-center gap-2 text-emerald-600 font-black text-xs uppercase tracking-widest mb-4">
                    <Package size={16} /> {selectedItem.category}
                  </div>
                  <h2 className="text-4xl font-black mb-4 tracking-tight">{selectedItem.name}</h2>
                  <p className="text-slate-500 text-lg leading-relaxed font-medium">{selectedItem.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border dark:border-slate-700">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{t.condition}</p>
                    <p className="font-black text-emerald-600">{selectedItem.condition}</p>
                  </div>
                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border dark:border-slate-700">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{t.pickup}</p>
                    <p className="font-black text-blue-600 flex items-center gap-1"><MapPin size={14}/> {selectedItem.pickupLocation}</p>
                  </div>
                </div>

                <div className="p-6 glass rounded-[2rem] border-slate-200/50 flex flex-col items-center gap-4 text-center">
                   <p className="font-black text-sm flex items-center gap-2"><QrCode size={18} className="text-emerald-500" /> {t.qrCode}</p>
                   <div className="p-4 bg-white rounded-2xl shadow-inner">
                      <QRCodeSVG 
                        value={`ITEM:${selectedItem.id}|PICKUP:${selectedItem.pickupLocation}`} 
                        size={120} 
                        bgColor="transparent" 
                        fgColor={theme === 'dark' ? '#1e293b' : '#000000'} 
                      />
                   </div>
                   <p className="text-[10px] text-slate-500 font-medium px-8">{t.qrDesc}</p>
                </div>

                <button className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-black text-xl shadow-xl shadow-emerald-500/20 active-liquid">
                   {language === 'ar' ? 'طلب استلام' : 'Request Pickup'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Post Request Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white dark:bg-slate-900 p-10 rounded-[2.5rem] shadow-2xl max-w-md w-full relative animate-in zoom-in-95 duration-300 border border-emerald-500/10">
            <button onClick={() => setShowRequestModal(false)} className="absolute top-6 right-6 p-2 text-slate-400 hover:text-rose-500"><X /></button>
            <h3 className="text-3xl font-black mb-6 tracking-tight">{t.postRequest}</h3>
            <form onSubmit={handlePostRequest} className="space-y-6">
              <div>
                <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Item Name</label>
                <input 
                  required 
                  value={requestInput.name}
                  onChange={e => setRequestInput({...requestInput, name: e.target.value})}
                  className="w-full p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border dark:border-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  placeholder="e.g. Scientific Calculator"
                />
              </div>
              <div>
                <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Category</label>
                <select 
                  value={requestInput.category}
                  onChange={e => setRequestInput({...requestInput, category: e.target.value as Category})}
                  className="w-full p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border dark:border-slate-800 outline-none font-bold"
                >
                  {['Stationery', 'Electronics', 'Books', 'Uniforms', 'Art Supplies', 'Other'].map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <button className="w-full bg-emerald-600 text-white py-4 rounded-xl font-black text-lg shadow-xl shadow-emerald-500/20 active-liquid">
                {language === 'ar' ? 'نشر الطلب' : 'Post Request'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Marketplace;
