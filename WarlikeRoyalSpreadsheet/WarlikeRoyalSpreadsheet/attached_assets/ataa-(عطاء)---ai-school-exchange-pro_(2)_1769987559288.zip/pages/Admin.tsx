
import React, { useState, useEffect } from 'react';
import { ShieldCheck, BarChart3, Users, AlertCircle, Check, X, Search, Clock, Sparkles, Loader2, Zap } from 'lucide-react';
import { SchoolItem, Language } from '../types';
import { translations } from '../lib/translations';
import { getAdminInsights } from '../lib/gemini';

interface AdminProps {
  items: SchoolItem[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  language: Language;
}

const Admin: React.FC<AdminProps> = ({ items, onApprove, onReject, language }) => {
  const t = translations[language];
  const pendingItems = items.filter(i => i.status === 'pending');
  const [aiInsights, setAiInsights] = useState<{ summary: string, topNeed: string, riskLevel: string } | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  useEffect(() => {
    const fetchInsights = async () => {
      setLoadingInsights(true);
      try {
        const insights = await getAdminInsights(JSON.stringify(items.slice(0, 20)));
        setAiInsights(insights);
      } catch (err) {
        console.error(err);
      } finally {
        setLoadingInsights(false);
      }
    };
    if (items.length > 0) fetchInsights();
  }, [items]);

  return (
    <div className="space-y-8 animate-in slide-in-from-top-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <ShieldCheck size={32} className="text-emerald-500" /> {t.admin}
          </h1>
          <p className="text-slate-500">{language === 'ar' ? 'إدارة المحتوى ومراجعة الأدوات المرفوعة.' : 'Manage content and review uploaded items.'}</p>
        </div>
      </div>

      {/* AI Co-Pilot Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gradient-to-br from-indigo-600 to-blue-700 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
          <div className="relative z-10">
            <h3 className="text-xl font-black mb-4 flex items-center gap-2">
              <Sparkles className="text-amber-300" /> 
              {language === 'ar' ? 'ملخص الذكاء الاصطناعي للمشرف' : 'AI Admin Insights'}
            </h3>
            {loadingInsights ? (
              <div className="flex items-center gap-3">
                <Loader2 className="animate-spin" />
                <p className="font-bold opacity-70">Analyzing community needs...</p>
              </div>
            ) : aiInsights ? (
              <div className="space-y-4">
                <p className="text-lg font-medium opacity-90 leading-relaxed">{aiInsights.summary}</p>
                <div className="flex gap-4">
                  <div className="bg-white/20 px-4 py-2 rounded-xl text-sm font-black border border-white/10">
                    TOP NEED: {aiInsights.topNeed}
                  </div>
                  <div className={`px-4 py-2 rounded-xl text-sm font-black border border-white/10 ${aiInsights.riskLevel === 'High' ? 'bg-rose-500/40' : 'bg-emerald-500/40'}`}>
                    RISK: {aiInsights.riskLevel}
                  </div>
                </div>
              </div>
            ) : (
              <p className="opacity-50">Upload items to generate insights.</p>
            )}
          </div>
          <Zap size={200} className="absolute -right-20 -bottom-20 text-white opacity-5 group-hover:rotate-12 transition-transform duration-700" />
        </div>

        <div className="glass p-8 rounded-[2.5rem] flex flex-col items-center justify-center text-center space-y-2">
           <BarChart3 size={48} className="text-emerald-500 mb-2" />
           <p className="text-4xl font-black">{items.length}</p>
           <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Total Community Assets</p>
        </div>
      </div>

      {/* Moderation Table */}
      <div className="glass rounded-[2rem] overflow-hidden border-emerald-500/10">
        <div className="p-8 border-b dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-xl font-bold flex items-center gap-2">
             <Clock size={20} className="text-amber-500" />
             {language === 'ar' ? 'طلبات قيد المراجعة' : 'Pending Approvals'}
             <span className="bg-amber-100 text-amber-600 px-2 py-0.5 rounded-lg text-xs">{pendingItems.length}</span>
          </h3>
        </div>

        {pendingItems.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-900/50 text-slate-500 text-xs font-bold uppercase">
                <tr>
                  <th className={`px-8 py-4 ${language === 'ar' ? 'text-right' : ''}`}>{language === 'ar' ? 'الأداة' : 'Item'}</th>
                  <th className={`px-8 py-4 ${language === 'ar' ? 'text-right' : ''}`}>{language === 'ar' ? 'المتبرع' : 'Donor'}</th>
                  <th className={`px-8 py-4 ${language === 'ar' ? 'text-right' : ''}`}>{language === 'ar' ? 'الفئة' : 'Category'}</th>
                  <th className={`px-8 py-4 text-center`}>{language === 'ar' ? 'الإجراء' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y dark:divide-slate-800">
                {pendingItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/30">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <img src={item.imageUrl} className="w-12 h-12 rounded-xl object-cover" />
                        <div>
                          <p className="font-bold">{item.name}</p>
                          <p className="text-xs text-slate-500">{item.condition}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6 font-medium text-sm">{item.donorName}</td>
                    <td className="px-8 py-6">
                       <span className="bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full text-xs font-bold">{item.category}</span>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center justify-center gap-2">
                        <button 
                          onClick={() => onApprove(item.id)}
                          className="bg-emerald-100 text-emerald-600 p-2.5 rounded-xl hover:bg-emerald-600 hover:text-white transition-all"
                        >
                          <Check size={20} />
                        </button>
                        <button 
                          onClick={() => onReject(item.id)}
                          className="bg-rose-100 text-rose-600 p-2.5 rounded-xl hover:bg-rose-600 hover:text-white transition-all"
                        >
                          <X size={20} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-20 text-center opacity-50">
            <p className="font-bold">{language === 'ar' ? 'لا يوجد طلبات حالياً' : 'No pending requests'}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;
