
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * AI Vision: Analyzes images for safety, categorizes them, 
 * and generates catchy, professional titles and descriptions.
 */
export const analyzeItemImage = async (base64Image: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
          { text: `Analyze this image for a school resource exchange app called 'Ataa'. 
            1. SAFETY CHECK: Is this appropriate for school? (No weapons, non-educational items).
            2. AUTO-CONTENT: Generate a 'catchyName' (e.g. 'Ultimate Physics Bundle' instead of 'Physics Book') and a 'catchyDescription' that motivates other students.
            3. CATEGORY: stationery, electronics, books, uniforms, art supplies, other.
            4. CONDITION: New, Like New, Good, Fair.
            Return 'unsafe' if it fails safety.` }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isSafe: { type: Type.BOOLEAN },
            name: { type: Type.STRING },
            category: { type: Type.STRING },
            description: { type: Type.STRING },
            condition: { type: Type.STRING }
          },
          required: ["isSafe"]
        }
      }
    });

    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr || '{}');
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};

/**
 * AI Semantic Search: Maps human needs to specific marketplace filters.
 * E.g., "I'm cold" -> Uniforms (Sweaters)
 */
export const performSemanticSearch = async (query: string, language: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User says: "${query}". 
      From these categories: [Stationery, Electronics, Books, Uniforms, Art Supplies, Other], 
      which one fits best? Also suggest 3 keywords for items. 
      Language: ${language}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING },
            keywords: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });
    return JSON.parse(response.text.trim());
  } catch (err) {
    return { category: 'All', keywords: [] };
  }
};

/**
 * AI Admin Insights: Summarizes community activity and flags risks.
 */
export const getAdminInsights = async (itemsJson: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze these school items: ${itemsJson}. 
      What is the most needed category? Any suspicious patterns? 
      Provide a brief summary for a teacher.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            topNeed: { type: Type.STRING },
            riskLevel: { type: Type.STRING, description: "Low, Medium, High" }
          }
        }
      }
    });
    return JSON.parse(response.text.trim());
  } catch (err) {
    return null;
  }
};

export const askAtaaAssistant = async (prompt: string, language: string, context?: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: `You are Ataa Assistant. Help students with school exchange.
        Current Context: ${context || 'General navigation'}. 
        Provide sustainability tips. Be bilingual (${language}).`
      }
    });
    return response.text;
  } catch (error) {
    return "Connection issues.";
  }
};
