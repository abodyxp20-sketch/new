
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Marketplace from './pages/Marketplace';
import Upload from './pages/Upload';
import Settings from './pages/Settings';
import Admin from './pages/Admin';
import AIChatbot from './components/AIChatbot';
import { UserProfile, SchoolItem, Language, ThemeMode, Badge, ItemRequest } from './types';
import { translations } from './lib/translations';
import { ShieldAlert, X, Award, Bell } from 'lucide-react';

const INITIAL_USER: UserProfile = {
  id: 'u1',
  displayName: 'Sarah Ahmed',
  email: 'sarah.a@school.edu',
  grade: 'Grade 11-A',
  bio: 'Eco-conscious student leader. Helping every student succeed!',
  interests: ['Science', 'Art'],
  profilePic: 'https://i.pravatar.cc/150?u=sarah',
  socialPoints: 450,
  unlockedBadges: ['first-give', 'eco-hero'],
  role: 'Student', 
  preferences: {
    theme: 'system',
    notifications: { email: true, inApp: true },
    language: 'ar',
    privacyShowHistory: true
  }
};

const INITIAL_ITEMS: SchoolItem[] = [
  { id: '1', name: 'MacBook Air M1 Case', category: 'Electronics', condition: 'Like New', imageUrl: 'https://picsum.photos/seed/laptop/400/300', donorName: 'Omar K.', donorId: 'u2', createdAt: Date.now() - 3600000, description: 'Clear protective case.', isAvailable: true, status: 'approved', pickupLocation: 'Library' },
  { id: '2', name: 'AP Physics 1 Textbook', category: 'Books', condition: 'Good', imageUrl: 'https://picsum.photos/seed/book/400/300', donorName: 'Sarah Ahmed', donorId: 'u1', createdAt: Date.now() - 86400000, description: 'Used AP Physics guide.', isAvailable: true, status: 'approved', pickupLocation: 'Locker 42' },
];

export const ALL_BADGES: Badge[] = [
  { id: 'first-give', nameEn: 'First Giver', nameAr: 'أول عطاء', icon: '🌟', color: 'bg-amber-400', condition: 'Donate 1 item' },
  { id: 'eco-hero', nameEn: 'Eco Hero', nameAr: 'بطل البيئة', icon: '🌿', color: 'bg-emerald-500', condition: 'Donate 5 items' },
  { id: 'top-donor', nameEn: 'Top Donor', nameAr: 'أبرز المتبرعين', icon: '👑', color: 'bg-blue-500', condition: 'Top 3 on leaderboard' },
  { id: 'alaa-legend', nameEn: 'Ataa Legend', nameAr: 'أسطورة عطاء', icon: '💎', color: 'bg-indigo-600', condition: '1000+ Points' }
];

const SecurityShield: React.FC<{ message: string; onClose: () => void }> = ({ message, onClose }) => (
  <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
    <div className="bg-white dark:bg-slate-900 p-8 md:p-10 rounded-[2.5rem] shadow-2xl max-w-md w-full text-center space-y-6 border border-rose-500/20">
      <div className="w-20 h-20 md:w-24 md:h-24 bg-rose-100 dark:bg-rose-900/30 text-rose-600 rounded-full flex items-center justify-center mx-auto">
        <ShieldAlert size={56} />
      </div>
      <h3 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white">Security Shield</h3>
      <p className="text-slate-500 text-lg leading-relaxed">{message}</p>
      <button 
        onClick={onClose}
        className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-black text-lg active:scale-95 transition-all shadow-xl shadow-emerald-500/20"
      >
        Dismiss
      </button>
    </div>
  </div>
);

const AppContent: React.FC = () => {
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('ataa_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });
  const [items, setItems] = useState<SchoolItem[]>(() => {
    const saved = localStorage.getItem('ataa_items');
    return saved ? JSON.parse(saved) : INITIAL_ITEMS;
  });
  const [requests, setRequests] = useState<ItemRequest[]>(() => {
    const saved = localStorage.getItem('ataa_requests');
    return saved ? JSON.parse(saved) : [];
  });
  const [language, setLanguage] = useState<Language>(user.preferences.language);
  const [theme, setTheme] = useState<ThemeMode>(user.preferences.theme);
  const [securityAlert, setSecurityAlert] = useState<string | null>(null);
  const [matchNotification, setMatchNotification] = useState<string | null>(null);

  const location = useLocation();
  const navigate = useNavigate();
  const t = translations[language];

  useEffect(() => {
    localStorage.setItem('ataa_user', JSON.stringify(user));
    setLanguage(user.preferences.language);
    setTheme(user.preferences.theme);
  }, [user]);

  useEffect(() => {
    localStorage.setItem('ataa_items', JSON.stringify(items));
    localStorage.setItem('ataa_requests', JSON.stringify(requests));
    
    // Auto-calculate badges
    const userItems = items.filter(i => i.donorId === user.id);
    const newBadges = [...user.unlockedBadges];
    if (userItems.length >= 1 && !newBadges.includes('first-give')) newBadges.push('first-give');
    if (userItems.length >= 5 && !newBadges.includes('eco-hero')) newBadges.push('eco-hero');
    if (user.socialPoints >= 1000 && !newBadges.includes('alaa-legend')) newBadges.push('alaa-legend');
    
    if (newBadges.length !== user.unlockedBadges.length) {
      setUser(prev => ({ ...prev, unlockedBadges: newBadges }));
    }
  }, [items, requests, user.socialPoints]);

  useEffect(() => {
    const applyTheme = (mode: ThemeMode) => {
      const isDark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
      document.documentElement.classList.toggle('dark', isDark);
    };
    applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    if (location.pathname === '/admin' && user.role === 'Student') {
      setSecurityAlert(t.securityAlert);
      navigate('/');
    }
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const toggleLanguage = () => {
    const nextLang = language === 'ar' ? 'en' : 'ar';
    setUser(prev => ({ ...prev, preferences: { ...prev.preferences, language: nextLang } }));
  };

  const handleUpload = (item: SchoolItem) => {
    setItems(prev => {
      const index = prev.findIndex(i => i.id === item.id);
      if (index !== -1) {
        const newItems = [...prev];
        newItems[index] = item;
        return newItems;
      }
      return [item, ...prev];
    });

    // Check for wishlist matches
    const matchingRequest = requests.find(req => 
      item.name.toLowerCase().includes(req.itemName.toLowerCase()) || 
      req.itemName.toLowerCase().includes(item.name.toLowerCase())
    );

    if (matchingRequest && matchingRequest.studentId === user.id) {
       setMatchNotification(t.matchFound);
       setTimeout(() => setMatchNotification(null), 5000);
    }

    if (!items.find(i => i.id === item.id)) {
      setUser(prev => ({ ...prev, socialPoints: prev.socialPoints + 50 }));
    }
  };

  const handlePostRequest = (req: ItemRequest) => {
    setRequests(prev => [req, ...prev]);
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-24 md:pb-0 ${language === 'ar' ? 'rtl font-arabic' : 'ltr'}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {securityAlert && <SecurityShield message={securityAlert} onClose={() => setSecurityAlert(null)} />}
      
      {matchNotification && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-4 duration-500">
          <div className="bg-emerald-600 text-white px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-4">
            <Bell className="animate-bounce" />
            <p className="font-black">{matchNotification}</p>
            <button onClick={() => setMatchNotification(null)}><X size={18}/></button>
          </div>
        </div>
      )}

      <Navbar 
        user={user} 
        theme={theme}
        language={language} 
        toggleLanguage={toggleLanguage} 
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-8 overflow-x-hidden">
        <Routes>
          <Route path="/" element={<Home user={user} language={language} items={items} />} />
          <Route path="/marketplace" element={<Marketplace items={items.filter(i => i.status === 'approved')} requests={requests} user={user} language={language} theme={theme} onPostRequest={handlePostRequest} />} />
          <Route path="/upload" element={<Upload user={user} language={language} onUpload={handleUpload} />} />
          <Route path="/upload/:itemId" element={<Upload user={user} language={language} onUpload={handleUpload} items={items} />} />
          <Route path="/settings" element={<Settings user={user} setUser={setUser} theme={theme} setTheme={(m) => setUser(prev => ({...prev, preferences: {...prev.preferences, theme: m}}))} language={language} toggleLanguage={toggleLanguage} />} />
          <Route path="/admin" element={user.role === 'Admin' || user.role === 'Teacher' ? <Admin items={items} onApprove={(id) => setItems(prev => prev.map(i => i.id === id ? {...i, status: 'approved'} : i))} onReject={(id) => setItems(prev => prev.filter(i => i.id !== id))} language={language} /> : <Navigate to="/" />} />
        </Routes>
      </main>

      <AIChatbot language={language} />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <AppContent />
    </HashRouter>
  );
};

export default App;
