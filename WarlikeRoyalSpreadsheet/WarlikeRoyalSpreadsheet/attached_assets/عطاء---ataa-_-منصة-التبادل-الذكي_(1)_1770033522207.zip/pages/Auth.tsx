
// This file is deprecated as Auth functionality has moved to Settings.tsx
export default () => null;
