
import React, { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Upload as UploadIcon, Loader2, CheckCircle, Sparkles, UserCircle, LogIn, Camera } from 'lucide-react';
import { analyzeItemImage } from '../lib/gemini';
import { db, uploadImage, collection, addDoc, doc, updateDoc } from '../lib/firebase';
import { UserProfile, SchoolItem, Category, Language } from '../types';
import { translations } from '../lib/translations';

interface UploadProps {
  user: UserProfile | null;
  language: Language;
  onUpload: (item: SchoolItem) => void;
  items?: SchoolItem[];
}

const Upload: React.FC<UploadProps> = ({ user, language, items }) => {
  const { itemId } = useParams();
  const navigate = useNavigate();
  const editItem = itemId && items ? items.find(i => i.id === itemId) : null;

  const [image, setImage] = useState<string | null>(editItem?.imageUrl || null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const t = translations[language];
  
  const [formData, setFormData] = useState({
    name: editItem?.name || '',
    description: editItem?.description || '',
    notes: editItem?.notes || '',
    pickupLocation: editItem?.pickupLocation || '',
    category: (editItem?.category as Category) || 'Stationery',
    condition: (editItem?.condition as SchoolItem['condition']) || 'Good'
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        setImage(base64String);
        setIsAnalyzing(true);
        setError(null);
        try {
          const pureBase64 = base64String.split(',')[1];
          const result = await analyzeItemImage(pureBase64);
          if (result.isSafe === false) {
            setError(t.safetyError);
            setImage(null);
            return;
          }
          setFormData(prev => ({
            ...prev,
            name: result.name || prev.name,
            description: result.description || prev.description,
            category: (result.category as Category) || prev.category,
            condition: (result.condition as any) || prev.condition
          }));
        } catch (err) {
          setError("AI analysis failed.");
        } finally {
          setIsAnalyzing(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!image) return;
    setIsUploading(true);
    try {
      let finalImageUrl = image;
      if (image.startsWith('data:')) {
        finalImageUrl = await uploadImage(`items/${user?.id || 'guest'}_${Date.now()}`, image);
      }

      const donorId = user?.id || 'guest';
      const donorName = user?.displayName || (language === 'ar' ? 'ضيف عطاء' : 'Ataa Guest');

      if (editItem) {
        await updateDoc(doc(db, "items", editItem.id), { ...formData, imageUrl: finalImageUrl, status: 'pending' });
      } else {
        await addDoc(collection(db, "items"), {
          ...formData,
          imageUrl: finalImageUrl,
          donorId: donorId,
          donorName: donorName,
          isAvailable: true,
          status: 'pending',
          createdAt: Date.now()
        });
      }
      setSuccess(true);
    } catch (err) {
      setError("Cloud save failed.");
    } finally {
      setIsUploading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center space-y-8 animate-fade-up">
        <div className="w-28 h-28 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 squircle-lg flex items-center justify-center mx-auto shadow-2xl">
          <CheckCircle size={64} />
        </div>
        <div>
          <h2 className="text-5xl font-black tracking-tighter mb-4">{editItem ? 'تم التحديث!' : 'تم الحفظ بنجاح!'}</h2>
          <p className="text-slate-500 text-xl font-medium leading-relaxed">
            {language === 'ar' 
              ? 'مساهمتك الآن بانتظار مراجعة المشرفين المدرسيين. شكراً لعطائك!' 
              : 'Your contribution is now awaiting review by school moderators. Thank you for giving!'}
          </p>
        </div>
        <button onClick={() => navigate('/marketplace')} className="bg-emerald-600 text-white px-12 py-5 rounded-[22px] font-black text-xl shadow-2xl hover-lift tap-active">
          {language === 'ar' ? 'العودة لمركز عطاء' : 'Return to Ataa Hub'}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto pb-32 animate-fade-up px-4">
      <div className="mb-12">
        <div className="inline-flex items-center gap-2 glass border-emerald-500/20 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] text-emerald-600 mb-6">
          <Sparkles size={14} /> {language === 'ar' ? 'مساهمة مفتوحة للجميع' : 'Open Contribution'}
        </div>
        <h1 className="text-5xl md:text-7xl font-black mb-4 tracking-tighter">
          {editItem ? (language === 'ar' ? 'تعديل المقتنى' : 'Edit Listing') : t.uploadTitle}
        </h1>
        <p className="text-slate-500 text-xl font-medium leading-relaxed max-w-2xl">
          {t.uploadDesc}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div className="space-y-8">
          <div 
            onClick={() => fileInputRef.current?.click()} 
            className={`aspect-square squircle-lg border-4 border-dashed transition-all cursor-pointer flex flex-col items-center justify-center overflow-hidden bg-slate-100 dark:bg-slate-900/50 shadow-2xl group ${image ? 'border-emerald-500' : 'border-slate-300 dark:border-slate-800 hover:border-emerald-400'}`}
          >
            {image ? (
              <img src={image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            ) : (
              <div className="text-center p-12">
                <div className="w-20 h-20 bg-white dark:bg-slate-800 squircle flex items-center justify-center mx-auto mb-6 shadow-xl text-emerald-600">
                  <Camera size={36} />
                </div>
                <p className="font-black text-2xl tracking-tight text-slate-400">
                  {language === 'ar' ? 'التقط صورة للأداة' : 'Capture Gear Photo'}
                </p>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-2">
                  Gemini AI will analyze it instantly
                </p>
              </div>
            )}
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageChange} />
          </div>
          
          {isAnalyzing && (
            <div className="p-6 glass border-emerald-500/20 rounded-[25px] flex items-center gap-4 animate-pulse">
              <Loader2 className="animate-spin text-emerald-600" size={24} />
              <div className="flex-1">
                <p className="font-black text-sm tracking-tight">
                  {language === 'ar' ? 'محرك Gemini الذكي يحلل الصورة...' : 'Gemini AI Engine is analyzing...'}
                </p>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Identifying category and condition</p>
              </div>
            </div>
          )}
          
          {error && (
            <div className="p-6 glass bg-rose-50 dark:bg-rose-900/10 border-rose-500/20 rounded-[25px] flex items-center gap-4">
              <LogIn className="text-rose-500" size={24} />
              <p className="font-black text-sm text-rose-500">{error}</p>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="glass p-10 md:p-14 squircle-lg space-y-10 shadow-[0_32px_64px_rgba(0,0,0,0.1)] border border-white/40">
          <div className="space-y-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] px-2">
                {language === 'ar' ? 'اسم المقتنى' : 'Item Name'}
              </label>
              <input 
                required 
                value={formData.name} 
                onChange={e => setFormData({...formData, name: e.target.value})} 
                className="w-full p-6 rounded-[22px] bg-white dark:bg-slate-900/50 border border-white/20 outline-none font-black text-xl shadow-inner focus:ring-4 focus:ring-emerald-500/10 transition-all" 
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] px-2">
                  {t.pickup}
                </label>
                <input 
                  required 
                  value={formData.pickupLocation} 
                  onChange={e => setFormData({...formData, pickupLocation: e.target.value})} 
                  className="w-full p-6 rounded-[22px] bg-white dark:bg-slate-900/50 border border-white/20 outline-none font-bold text-lg shadow-inner focus:ring-4 focus:ring-emerald-500/10 transition-all" 
                />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] px-2">
                  {t.condition}
                </label>
                <select 
                  value={formData.condition} 
                  onChange={e => setFormData({...formData, condition: e.target.value as any})} 
                  className="w-full p-6 rounded-[22px] bg-white dark:bg-slate-900/50 border border-white/20 outline-none font-bold text-lg shadow-inner appearance-none cursor-pointer focus:ring-4 focus:ring-emerald-500/10 transition-all"
                >
                  <option>New</option>
                  <option>Like New</option>
                  <option>Good</option>
                  <option>Fair</option>
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] px-2">
                {language === 'ar' ? 'وصف إضافي (اختياري)' : 'Description (Optional)'}
              </label>
              <textarea 
                value={formData.description} 
                onChange={e => setFormData({...formData, description: e.target.value})} 
                className="w-full p-6 rounded-[22px] bg-white dark:bg-slate-900/50 border border-white/20 outline-none font-medium text-lg shadow-inner h-32 resize-none focus:ring-4 focus:ring-emerald-500/10 transition-all"
              />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={!image || isUploading} 
            className="w-full py-6 rounded-[25px] bg-emerald-600 text-white font-black text-2xl shadow-2xl disabled:opacity-50 active:scale-95 transition-all hover-lift flex items-center justify-center gap-4"
          >
            {isUploading ? (
              <Loader2 className="animate-spin" size={28} />
            ) : (
              <>
                <Sparkles size={28} />
                {editItem ? (language === 'ar' ? 'حفظ التغييرات' : 'Save Changes') : (language === 'ar' ? 'نشر في مجتمع عطاء' : 'Publish to Ataa')}
              </>
            )}
          </button>
          
          {!user && (
            <p className="text-center text-xs text-slate-400 font-bold uppercase tracking-widest animate-pulse">
              {language === 'ar' ? 'أنت تشارك الآن كضيف - سيتم حفظ مقتنياتك محلياً' : 'Sharing as Guest - Your items will be saved locally'}
            </p>
          )}
        </form>
      </div>
    </div>
  );
};

export default Upload;
