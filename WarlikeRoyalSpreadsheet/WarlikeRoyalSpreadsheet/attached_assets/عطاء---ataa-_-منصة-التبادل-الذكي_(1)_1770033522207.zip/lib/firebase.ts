
/**
 * LOCAL STORAGE ENGINE (Ataa Local DB)
 * This replaces Firebase to make the app work instantly without external setup.
 */

// Mock Auth State
let authStateListener: ((user: any) => void) | null = null;

export const getLocalData = (key: string) => JSON.parse(localStorage.getItem(key) || '[]');
export const setLocalData = (key: string, data: any) => localStorage.setItem(key, JSON.stringify(data));

export const isFirebaseConfigured = true; // Always true for local mode

export const auth = {
  get currentUser() {
    return JSON.parse(localStorage.getItem('ataa_current_user') || 'null');
  }
};

export const onAuthStateChanged = (authObj: any, callback: (user: any) => void) => {
  authStateListener = callback;
  const user = JSON.parse(localStorage.getItem('ataa_current_user') || 'null');
  callback(user);
  return () => { authStateListener = null; };
};

// Fix: updated signature to accept authObj as expected by Settings.tsx line 143
export const signOut = async (authObj?: any) => {
  localStorage.removeItem('ataa_current_user');
  if (authStateListener) authStateListener(null);
};

// Mock Database (Firestore)
export const db = {
  // We use strings for collection names in this mock
};

export const doc = (db: any, collection: string, id: string) => ({ collection, id });

export const getDoc = async (docRef: any) => {
  const data = getLocalData(docRef.collection);
  const found = data.find((item: any) => item.id === docRef.id);
  return {
    exists: () => !!found,
    data: () => found
  };
};

export const setDoc = async (docRef: any, data: any) => {
  const collectionData = getLocalData(docRef.collection);
  const index = collectionData.findIndex((item: any) => item.id === docRef.id);
  if (index > -1) collectionData[index] = { ...collectionData[index], ...data };
  else collectionData.push({ ...data, id: docRef.id });
  setLocalData(docRef.collection, collectionData);
};

export const updateDoc = async (docRef: any, data: any) => {
  await setDoc(docRef, data);
};

export const addDoc = async (collectionName: any, data: any) => {
  const id = Math.random().toString(36).substr(2, 9);
  const collectionData = getLocalData(collectionName);
  const newItem = { ...data, id };
  collectionData.push(newItem);
  setLocalData(collectionName, collectionData);
  return { id };
};

export const deleteDoc = async (docRef: any) => {
  const collectionData = getLocalData(docRef.collection);
  const filtered = collectionData.filter((item: any) => item.id !== docRef.id);
  setLocalData(docRef.collection, filtered);
};

// Real-time listener mock
export const onSnapshot = (queryObj: any, callback: (snapshot: any) => void) => {
  const sync = () => {
    const data = getLocalData(queryObj.collectionName);
    callback({
      docs: data.map((d: any) => ({
        id: d.id,
        data: () => d
      }))
    });
  };
  
  sync();
  const interval = setInterval(sync, 1000); // Poll local storage for changes
  return () => clearInterval(interval);
};

export const query = (collectionName: string, ...args: any[]) => ({ collectionName });
export const collection = (db: any, name: string) => name;
export const orderBy = (...args: any[]) => ({});

// Mock Storage
export const uploadImage = async (path: string, fileOrBase64: File | string): Promise<string> => {
  // In local mode, we just return the base64 or a mock URL
  if (typeof fileOrBase64 === 'string') return fileOrBase64;
  
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.readAsDataURL(fileOrBase64 as File);
  });
};

export const storage = {};
export const EmailAuthProvider = {
  credential: (email: string, pass: string) => ({ email, pass })
};
// Fix: updated signature to accept user and credential as expected by Settings.tsx line 74
export const reauthenticateWithCredential = async (user: any, credential: any) => true;
export const updatePassword = async (user: any, pass: string) => {
  const currentUser = JSON.parse(localStorage.getItem('ataa_current_user') || '{}');
  const users = getLocalData('users');
  const index = users.findIndex((u: any) => u.id === currentUser.id);
  if (index > -1) {
    users[index].password = pass;
    setLocalData('users', users);
  }
};
export const getRedirectResult = async () => null;
